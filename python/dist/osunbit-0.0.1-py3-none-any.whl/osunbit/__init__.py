# osunbit/__init__.py
def add(a, b):
    return a + b
